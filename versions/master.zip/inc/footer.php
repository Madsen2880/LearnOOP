<kbd>Build: <?= $buildnr ?></kbd>
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
    $('#myAlert').alert('toogle')

</script>
</body>
</html>