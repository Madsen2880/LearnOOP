<kbd>Build: <?= $buildnr ?></kbd>
</body>
</html>